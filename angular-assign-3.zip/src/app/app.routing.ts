import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ContactModule} from './contact/contact.module';
import{ AboutModule} from './about/about.module';

const appRoute:Routes=[

{ path: '', component:HomeComponent },

{ path: 'contact', 
loadChildren: 'app/contact/contact.module#ContactModule' },

{ path:'about',
loadChildren: 'app/about/about.module#AboutModule'}
]
export const routing =RouterModule.forRoot(appRoute);