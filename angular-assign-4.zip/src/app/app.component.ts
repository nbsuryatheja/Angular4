import { Component, HostListener } from '@angular/core';

import {animate, query, stagger, style, transition, trigger, state} from '@angular/animations';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',

  animations: [
    trigger('AElement', [
      state('*', style({opacity: 1})),
      state('void', style({opacity: 0})),
      transition(':enter', animate('1s ease-in')),
      transition(':leave', animate('7s ease-out'))
    ]),
    trigger('BElement', [
      state('*', style({opacity: 1})),
      state('void', style({opacity: 0})),
      transition(':enter', animate('3s ease-in')),
      transition(':leave', animate('4s ease-out'))
    ]),
    trigger('CElement', [
      state('*', style({opacity: 1})),
      state('void', style({opacity: 0})),
      transition(':enter', animate('5s 3s ease-in')),
      transition(':leave', animate('2s ease-out'))
    ])
  ]
})
export class AppComponent  {
  elementshow:boolean=true;

  ngOnInit() {
        setInterval(() => this.elementshow = !this.elementshow, 9000);
    }
}
