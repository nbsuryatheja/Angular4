import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { ServicesComponent } from './services/services.component';
import { ProjectsComponent } from './projects/projects.component';
import { ContactComponent } from './contact/contact.component';

const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'project', component: ProjectsComponent },
  { path: 'service', component: ServicesComponent },
  { path: 'contact', component: ContactComponent }
];

export const routing = RouterModule.forRoot(appRoutes);

